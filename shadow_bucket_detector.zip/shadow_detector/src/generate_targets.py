#!/usr/bin/env python3
# src/generate_targets.py
import sys
import re
import os
import argparse
from pathlib import Path
from typing import List, Set

# reuse enumerator's anonymous client if available
try:
    from enumerator import ANON_S3
except Exception:
    # fallback to creating an unsigned client if enumerator not importable
    import boto3
    from botocore import UNSIGNED
    from botocore.config import Config
    ANON_S3 = boto3.client("s3", config=Config(signature_version=UNSIGNED))

from botocore.exceptions import ClientError

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = PROJECT_ROOT / "targets.txt"


def normalize_domain(d: str) -> str:
    d = d.strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = d.split("/", 1)[0]
    if d.startswith("www."):
        d = d[4:]
    return d


def small_variants(domain: str) -> List[str]:
    d = normalize_domain(domain)
    hyphen = re.sub(r"[^a-z0-9\.]", "", d).replace(".", "-")
    raw = re.sub(r"[^a-z0-9]", "", d)
    candidates = [
        hyphen,
        raw,
        f"{hyphen}-prod",
        f"{hyphen}-dev",
        f"{hyphen}-staging",
        f"{hyphen}-assets",
        f"assets-{hyphen}",
        f"static-{hyphen}",
        f"{hyphen}-uploads",
        f"{hyphen}-backup",
        f"{hyphen}-logs",
    ]
    # sanitize and dedupe
    out = []
    for c in candidates:
        c2 = re.sub(r"[^a-z0-9\-]", "", c.lower()).strip("-")
        if c2 and c2 not in out:
            out.append(c2)
    return out


def probe_exists(bucket: str) -> bool:
    """
    Return True if the bucket likely exists.
    HEAD bucket anonymous: 403 usually -> exists but private; 404 -> not exist.
    """
    try:
        ANON_S3.head_bucket(Bucket=bucket)
        return True
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        # NoSuchBucket or 404 indicates likely not existing
        if code in ("404", "NoSuchBucket"):
            return False
        # AccessDenied/403 and others likely mean bucket exists but private
        return True
    except Exception:
        # On unexpected errors (network), return False conservatively
        return False


def generate_and_filter(seeds: List[str]) -> Set[str]:
    found = set()
    checked = set()
    for seed in seeds:
        seed = seed.strip()
        if not seed:
            continue
        variants = small_variants(seed)
        for v in variants:
            if v in checked:
                continue
            checked.add(v)
            if probe_exists(v):
                found.add(v)
                print(f"[+] Found: {v}")
            else:
                print(f"[-] Not found: {v}")
    return found


def read_seeds_from_file(path: Path) -> List[str]:
    with open(path, "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.strip().startswith("#")]


def write_targets(targets: Set[str], out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        for t in sorted(targets):
            fh.write(t + "\n")
    print(f"[+] Wrote {len(targets)} targets to {out_path}")


def cli():
    p = argparse.ArgumentParser(description="Generate & filter S3 bucket candidates (write existing to targets.txt)")
    p.add_argument("seed", help="Domain or path to file with domains (one per line)")
    p.add_argument("--out", "-o", default=str(DEFAULT_OUT), help="Output targets file (default: targets.txt in project root)")
    args = p.parse_args()

    seed_arg = args.seed
    path = Path(seed_arg)
    if path.exists() and path.is_file():
        seeds = read_seeds_from_file(path)
    else:
        seeds = [seed_arg]

    targets = generate_and_filter(seeds)
    write_targets(targets, Path(args.out))


if __name__ == "__main__":
    cli()

