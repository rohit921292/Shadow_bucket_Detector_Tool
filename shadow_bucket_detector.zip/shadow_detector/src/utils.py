# src/utils.py
import logging
import time
import random
from typing import Iterable, Iterator

logger = logging.getLogger("shadow_detector")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("[%(levelname)s] %(asctime)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

def show_banner():
    print("=" * 60)
    print("  Shadow Data Leakage Detector ")
    print(" Minor Project - 2025")
    print(" Developed by: Rohit Hulawale")
    print(" Amity University Jaipur")
    print("=" * 60)
    print()

def confirm_authorized(targets: Iterable[str], force: bool = False, dry_run: bool = False) -> bool:
    
    targets = list(targets)
    logger.info("Preparing to scan %d target(s).", len(targets))

    if force:
        logger.info("Force flag set — assuming authorization provided.")
        return True

    print("\nTargets to be scanned (only proceed if you own these or have written permission):")
    for t in targets:
        print("  -", t)
    if dry_run:
        print("\nDRY-RUN: no scanning will occur. Use --force to skip confirmation in automated runs.")
        return True

    ans = input("\nType 'YES' to confirm you have permission to scan these targets: ").strip()
    if ans == "YES":
        logger.info("Authorization confirmed by user.")
        return True
    logger.warning("Authorization NOT confirmed. Exiting.")
    return False

def rate_limited_iter(iterable: Iterable, base_sleep: float, jitter: float) -> Iterator:
    """
    Yield items but sleep between items with jitter to avoid uniform timing.
    """
    for idx, item in enumerate(iterable, start=1):
        logger.debug("Yielding item #%d: %s", idx, str(item))
        yield item
        sleep_time = base_sleep + random.uniform(0, jitter)
        logger.debug("Sleeping for %.2fs before next item.", sleep_time)
        time.sleep(sleep_time)

