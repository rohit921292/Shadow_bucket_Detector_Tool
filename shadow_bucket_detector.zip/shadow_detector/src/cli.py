# src/cli.py
import argparse
import sys
import logging
from typing import List, Dict

from config import BASE_SLEEP, JITTER, REPORT_FILENAME
from utils import show_banner, confirm_authorized, rate_limited_iter
from enumerator import aws_head_bucket_anonymous, aws_list_sample_anonymous
from permission_check import aws_safe_fetch_object
from sensitive_scan import scan_text_for_secrets
from report_gen import (
    generate_pdf_report,
    generate_json_report,
    generate_xml_report,
)

logger = logging.getLogger("shadow_detector")


def load_targets(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.strip().startswith("#")]


def scan_bucket(bucket_name: str, dry_run: bool = False) -> Dict:
    summary = {"bucket": bucket_name, "exists": False, "listable": False, "findings": [], "notes": []}
    exists, notes = aws_head_bucket_anonymous(bucket_name)
    summary["exists"] = bool(exists)
    summary["notes"].extend(notes or [])
    if not exists:
        return summary

    listable, sample_key, notes = aws_list_sample_anonymous(bucket_name)
    summary["listable"] = bool(listable)
    summary["notes"].extend(notes or [])

    if listable and sample_key:
        summary["notes"].append(f"sample_key={sample_key}")
        if dry_run:
            summary["notes"].append("dry-run: skipping content download and scanning")
            return summary
        data, notes = aws_safe_fetch_object(bucket_name, sample_key)
        summary["notes"].extend(notes or [])
        if data:
            try:
                text = data.decode("utf-8", errors="ignore")
                findings = scan_text_for_secrets(text)
                summary["findings"].extend(findings or [])
            except Exception as e:
                summary["notes"].append(f"decoding/scan error: {e}")
    return summary


def main():
    parser = argparse.ArgumentParser(description="Shadow Data Leakage Detector - modular")
    parser.add_argument("--targets", required=True, help="Path to file with bucket names (one per line)")
    parser.add_argument("--out", default=REPORT_FILENAME, help="Output report path")
    parser.add_argument("--format", choices=["pdf", "json", "xml"], default="pdf", help="Report output format")
    parser.add_argument("--force", action="store_true", help="Skip interactive auth confirmation")
    parser.add_argument("--dry-run", action="store_true", help="Do not download or scan object contents; preview only")
    parser.add_argument("--sleep", type=float, default=BASE_SLEEP, help="Base seconds between scans")
    args = parser.parse_args()

    show_banner()

    try:
        targets = load_targets(args.targets)
    except Exception as e:
        logger.error("Failed to load targets: %s", e)
        sys.exit(1)

    if not confirm_authorized(targets, force=args.force, dry_run=args.dry_run):
        sys.exit(1)

    summary_all: List[Dict] = []
    for t in rate_limited_iter(targets, base_sleep=args.sleep, jitter=JITTER):
        logger.info("Scanning %s", t)
        try:
            item = scan_bucket(t, dry_run=args.dry_run)
            summary_all.append(item)
        except Exception as e:
            logger.exception("Unexpected error while scanning %s: %s", t, e)

    logger.info("Generating report to %s (format=%s)", args.out, args.format)
    fmt = args.format.lower()
    try:
        if fmt == "pdf":
            generate_pdf_report(summary_all, args.out)
        elif fmt == "json":
            generate_json_report(summary_all, args.out)
        elif fmt == "xml":
            generate_xml_report(summary_all, args.out)
        else:
            logger.error("Unsupported format: %s", args.format)
            sys.exit(1)
    except Exception as e:
        logger.exception("Failed to generate report: %s", e)
        sys.exit(1)

    logger.info("Done. Report saved to %s", args.out)


if __name__ == "__main__":
    main()

