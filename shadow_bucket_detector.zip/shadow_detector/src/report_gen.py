# src/report_gen.py
"""
Report generation: PDF (existing), plus JSON and XML exports.
"""
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import datetime
from typing import List, Dict, Any
import json
import xml.etree.ElementTree as ET

def generate_pdf_report(summary: List[Dict], out_path: str):
    c = canvas.Canvas(out_path, pagesize=letter)
    width, height = letter
    y = height - 50
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y, "Shadow Data Leakage Detector - Report")
    c.setFont("Helvetica", 10)
    y -= 20
    c.drawString(50, y, f"Generated: {datetime.datetime.utcnow().isoformat()} UTC")
    y -= 30

    for item in summary:
        if y < 120:
            c.showPage()
            y = height - 50
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y, f"Bucket: {item.get('bucket')}  (exists={item.get('exists')}, listable={item.get('listable')})")
        y -= 16
        c.setFont("Helvetica", 10)
        for n in item.get('notes', []):
            c.drawString(60, y, f"- Note: {n}")
            y -= 12
            if y < 120:
                c.showPage()
                y = height - 50
        findings = item.get('findings', [])
        if findings:
            c.drawString(60, y, "Findings:")
            y -= 14
            for f in findings:
                s = f"{f['type']} ({f['confidence']}): {f['match']}"
                c.drawString(70, y, s[:1000])
                y -= 12
                if y < 120:
                    c.showPage()
                    y = height - 50
    c.save()

def generate_json_report(summary: List[Dict], out_path: str):
    """
    Writes the summary as a structured JSON file.
    """
    payload = {
        "report_name": "Shadow Data Leakage Detector",
        "generated_at": datetime.datetime.utcnow().isoformat() + "Z",
        "summary": summary
    }
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)

def _dict_to_xml_elem(tag: str, d: Dict[str, Any]) -> ET.Element:
    """
    Helper: convert a dict representing one bucket result into an XML element.
    """
    bucket_el = ET.Element(tag)
    for k, v in d.items():
        if k == "findings":
            findings_el = ET.SubElement(bucket_el, "findings")
            for f in v:
                f_el = ET.SubElement(findings_el, "finding")
                for fk, fv in f.items():
                    child = ET.SubElement(f_el, fk)
                    child.text = str(fv)
        elif k == "notes":
            notes_el = ET.SubElement(bucket_el, "notes")
            for note in v:
                n = ET.SubElement(notes_el, "note")
                n.text = str(note)
        else:
            child = ET.SubElement(bucket_el, k)
            child.text = str(v)
    return bucket_el

def generate_xml_report(summary: List[Dict], out_path: str):
    """
    Writes the summary as an XML file.
    """
    root = ET.Element("ShadowDataLeakageReport")
    meta = ET.SubElement(root, "metadata")
    gen = ET.SubElement(meta, "generated_at")
    gen.text = datetime.datetime.utcnow().isoformat() + "Z"
    buckets_el = ET.SubElement(root, "buckets")
    for item in summary:
        bucket_el = _dict_to_xml_elem("bucket", item)
        buckets_el.append(bucket_el)

    tree = ET.ElementTree(root)
    # Pretty-print: minimal approach
    _indent_xml(root)
    tree.write(out_path, encoding="utf-8", xml_declaration=True)

def _indent_xml(elem, level=0):
    """
    In-place pretty print indentation for ElementTree.
    """
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        for child in elem:
            _indent_xml(child, level+1)
        if not child.tail or not child.tail.strip():
            child.tail = i
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = i

