#!/usr/bin/env python3
"""
Patched src/main.py — robust imports, safe worker invocation, MINIO hint.
Drop into src/ replacing your existing main.py
"""
import argparse
import json
import os
import sys
import time
import traceback
import inspect
from concurrent.futures import ThreadPoolExecutor, as_completed

THIS_DIR = os.path.dirname(__file__)
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

DEFAULT_TARGETS = os.path.join(THIS_DIR, "..", "targets.txt")
DEFAULT_OUTPUT = os.path.join(THIS_DIR, "..", "report.json")


def safe_import(module_name):
    try:
        return __import__(module_name, fromlist=["*"])
    except Exception:
        return None


def load_buckets_from_file(path):
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Bucket list file not found: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return [l.strip() for l in fh if l.strip() and not l.strip().startswith("#")]


def save_json(results, output_path):
    output_path = os.path.abspath(output_path)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2)
    print(f"[+] Results written to {output_path}")


def threaded_worker_check(buckets, worker_fn, max_workers=10, **kwargs):
    """
    Threaded check that only forwards kwargs accepted by worker_fn.
    """
    results = []
    sig = inspect.signature(worker_fn)
    accepted = set(sig.parameters.keys())
    # Build pass_kwargs only with accepted names
    pass_kwargs = {k: v for k, v in kwargs.items() if k in accepted}

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(worker_fn, b, **pass_kwargs): b for b in buckets}
        for fut in as_completed(futures):
            b = futures[fut]
            try:
                res = fut.result()
            except Exception as e:
                # include traceback for debugging
                res = {"bucket": b, "error": str(e), "trace": traceback.format_exc()}
            results.append(res)
    return results


def main():
    parser = argparse.ArgumentParser(description="Shadow Bucket Detector - main runner")
    parser.add_argument("--file", "-f", default=DEFAULT_TARGETS, help="Path to bucket list (one per line)")
    parser.add_argument("--output", "-o", default=DEFAULT_OUTPUT, help="Path to JSON output report")
    parser.add_argument("--workers", "-w", default=10, type=int, help="Number of worker threads")
    parser.add_argument("--auth", action="store_true", help="Run authenticated checks (requires AWS creds)")
    parser.add_argument("--use-cli", action="store_true", help="If set, delegate execution to src/cli.py (if available)")
    parser.add_argument("--force-minio", action="store_true", help="Require MINIO env vars and refuse to scan AWS accidentally")
    args = parser.parse_args()

    # Helpful hint about MINIO env vars so user doesn't accidentally scan AWS
    MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT")
    if MINIO_ENDPOINT:
        print(f"[*] MINIO_ENDPOINT detected: {MINIO_ENDPOINT}")
    else:
        if args.force_minio:
            print("[ERROR] --force-minio set but MINIO_ENDPOINT is not present in environment. Aborting.")
            sys.exit(1)
        print("[!] MINIO_ENDPOINT not set — this run will target AWS S3 by default. "
              "If you intend to test locally with MinIO, export MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY")

    if args.use_cli:
        cli_mod = safe_import("cli")
        if cli_mod and hasattr(cli_mod, "main"):
            print("[*] Delegating run to cli.main()")
            try:
                cli_mod.main()
                return
            except Exception as e:
                print(f"[!] cli.main() failed: {e} — falling back to built-in runner")
        else:
            print("[!] cli module not available or has no main(); falling back to built-in runner")

    # Load buckets
    buckets = []
    enumerator = safe_import("enumerator")
    if enumerator and hasattr(enumerator, "load_buckets"):
        try:
            buckets = enumerator.load_buckets(args.file)
            print(f"[+] Loaded {len(buckets)} buckets via enumerator.load_buckets()")
        except Exception as e:
            print(f"[!] enumerator.load_buckets failed: {e} — falling back to file read")
    if not buckets:
        try:
            buckets = load_buckets_from_file(args.file)
            print(f"[+] Loaded {len(buckets)} buckets from file {args.file}")
        except Exception as e:
            print(f"[ERROR] Could not load buckets: {e}")
            sys.exit(1)

    # Find scan functions
    permission_mod = safe_import("permission_check")
    scan_fn = None
    worker_fn = None
    if permission_mod:
        for name in ("scan_buckets", "analyze_permissions", "run_scan"):
            if hasattr(permission_mod, name):
                scan_fn = getattr(permission_mod, name)
                break
        for name in ("check_bucket", "bucket_check", "check"):
            if hasattr(permission_mod, name):
                worker_fn = getattr(permission_mod, name)
                break

    if not scan_fn and not worker_fn:
        sensitive_mod = safe_import("sensitive_scan")
        if sensitive_mod and hasattr(sensitive_mod, "check_bucket"):
            worker_fn = getattr(sensitive_mod, "check_bucket")

    results = []
    start = time.time()
    try:
        if scan_fn:
            print(f"[*] Running scan using permission_check.{scan_fn.__name__} (auth={args.auth})")
            try:
                results = scan_fn(buckets, do_authenticated=args.auth)
            except TypeError:
                try:
                    results = scan_fn(buckets)
                except Exception as e:
                    print(f"[!] scan function error: {e}; will fall back to worker_fn")
        elif worker_fn:
            print(f"[*] Running threaded worker using {worker_fn.__module__}.{worker_fn.__name__} with {args.workers} workers")

            # robust _wrap using inspect.signature if needed
            def _wrap(bucket, **kw):
                try:
                    sig = inspect.signature(worker_fn)
                    # build call kwargs only from names worker accepts
                    call_kwargs = {}
                    for name, param in sig.parameters.items():
                        if name == 'bucket':
                            continue
                        if name in kw:
                            call_kwargs[name] = kw[name]
                    if len(sig.parameters) == 1:
                        return worker_fn(bucket)
                    else:
                        return worker_fn(bucket, **call_kwargs)
                except TypeError:
                    return worker_fn(bucket)
                except Exception:
                    raise

            results = threaded_worker_check(buckets, _wrap, max_workers=args.workers, do_authenticated=args.auth)
        else:
            print("[*] No scan functions found in permission_check/sensitive_scan. Using minimal built-in probe.")
            try:
                import boto3
                from botocore.config import Config
                from botocore import UNSIGNED
            except Exception:
                print("[ERROR] boto3 or botocore not installed or failed to import. Install from requirements.txt and retry.")
                traceback.print_exc()
                sys.exit(1)

            MINIO_ACCESS = os.getenv("MINIO_ACCESS_KEY")
            MINIO_SECRET = os.getenv("MINIO_SECRET_KEY")

            def minimal_check(bucket, do_authenticated=False):
                client_kwargs = {"config": Config(signature_version=UNSIGNED)}
                if MINIO_ENDPOINT:
                    client_kwargs["endpoint_url"] = MINIO_ENDPOINT
                    if MINIO_ACCESS:
                        client_kwargs["aws_access_key_id"] = MINIO_ACCESS
                    if MINIO_SECRET:
                        client_kwargs["aws_secret_access_key"] = MINIO_SECRET
                s3 = boto3.client("s3", **client_kwargs)
                try:
                    resp = s3.list_objects_v2(Bucket=bucket, MaxKeys=10)
                    if "Contents" in resp:
                        return {"bucket": bucket, "public": True, "objects": [o["Key"] for o in resp["Contents"]]}
                    else:
                        if resp.get("KeyCount", 0) > 0:
                            return {"bucket": bucket, "public": True, "objects": []}
                        return {"bucket": bucket, "public": False}
                except Exception as e:
                    return {"bucket": bucket, "error": str(e)}

            results = threaded_worker_check(buckets, minimal_check, max_workers=args.workers, do_authenticated=args.auth)

    except KeyboardInterrupt:
        print("\n[!] Interrupted by user")
    finally:
        elapsed = time.time() - start
        print(f"[*] Scan finished in {elapsed:.1f}s — {len(results)} results collected")

    # Try report_gen
    report_mod = safe_import("report_gen")
    if report_mod:
        if hasattr(report_mod, "save_json"):
            try:
                report_mod.save_json(results, output=args.output)
                return
            except Exception as e:
                print(f"[!] report_gen.save_json failed: {e} — falling back to local write")
        if hasattr(report_mod, "generate_report"):
            try:
                report_mod.generate_report(results, output_path=args.output)
                return
            except Exception as e:
                print(f"[!] report_gen.generate_report failed: {e} — falling back to local write")

    try:
        save_json(results, args.output)
    except Exception as e:
        print(f"[ERROR] Failed to save results: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()