# src/sensitive_scan.py
"""
Regex-based sensitive data scanning and simple heuristics.
You can expand this with entropy checks, ML models, or additional rules.
"""
import re
from typing import List, Dict

PATTERNS = {
    "aws_access_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "aws_secret_like": re.compile(r"(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])"),
    "email": re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"),
    "credit_card": re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
    "password_like": re.compile(r'(?i)\b(password|passwd|pwd)\b[:=]\s*["\']?[^"\']{4,100}'),
}

def luhn_check(card_number: str) -> bool:
    digits = [int(ch) for ch in re.sub(r'\D', '', card_number)]
    if not digits:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0

def scan_text_for_secrets(text: str) -> List[Dict]:
    findings = []
    for name, regex in PATTERNS.items():
        for m in regex.finditer(text):
            candidate = m.group(0)
            confidence = "low"
            if name == "credit_card":
                confidence = "high" if luhn_check(candidate) else "low"
            elif name.startswith("aws"):
                confidence = "high"
            findings.append({
                "type": name,
                "match": candidate,
                "confidence": confidence,
                "context": text[max(0, m.start()-40):m.end()+40]
            })
    return findings


