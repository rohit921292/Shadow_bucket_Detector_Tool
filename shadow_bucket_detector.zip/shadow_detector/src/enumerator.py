# src/enumerator.py
from typing import Tuple, List, Optional
import os

# AWS / boto3 imports
import boto3
from botocore import UNSIGNED
from botocore.config import Config
from botocore.exceptions import ClientError

# Detect MinIO / custom S3 endpoint via environment variables
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT")  # e.g. "http://127.0.0.1:9000"
MINIO_ACCESS = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET = os.getenv("MINIO_SECRET_KEY", "minioadmin")

# Create an S3 client suitable for anonymous checks.
# If MINIO_ENDPOINT is provided we create a client targeting that endpoint
# (we still use signature_version=UNSIGNED so calls resemble anonymous checks).
# For MinIO we pass basic access keys so MinIO accepts the requests; this is
# fine for local testing and keeps the rest of the code unchanged.
if MINIO_ENDPOINT:
    ANON_S3 = boto3.client(
        "s3",
        endpoint_url=MINIO_ENDPOINT,
        aws_access_key_id=MINIO_ACCESS,
        aws_secret_access_key=MINIO_SECRET,
        config=Config(signature_version=UNSIGNED),
    )
else:
    ANON_S3 = boto3.client("s3", config=Config(signature_version=UNSIGNED))


def aws_head_bucket_anonymous(bucket_name: str) -> Tuple[bool, List[str]]:
    """
    Check whether a bucket appears to exist (using anonymous HEAD).
    Returns:
      (exists_flag, notes_list)

    Notes:
      - A 404 / NoSuchBucket typically means "does not exist".
      - A 403 often means the bucket exists but denies public access.
      - Any unexpected exception is recorded in notes and considered non-existent for safety.
    """
    notes: List[str] = []
    try:
        ANON_S3.head_bucket(Bucket=bucket_name)
        # No exception -> bucket responded (may be public or private)
        return True, notes
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        notes.append(f"head_bucket error: {code}")
        # Treat NoSuchBucket/404 as not existing
        if code in ("404", "NoSuchBucket"):
            return False, notes
        # Other codes (e.g., 403) often imply bucket exists but is private
        return True, notes
    except Exception as e:
        notes.append(f"head_bucket unexpected error: {e}")
        return False, notes


def aws_list_sample_anonymous(bucket_name: str) -> Tuple[bool, Optional[str], List[str]]:
    """
    Try to list up to 1 object anonymously.
    Returns:
      (listable_flag, sample_object_key_or_None, notes_list)

    Behavior:
      - If anonymous listing is allowed and at least one object exists, returns (True, sample_key, notes).
      - If not listable or empty, returns (False, None, notes).
    """
    notes: List[str] = []
    try:
        resp = ANON_S3.list_objects_v2(Bucket=bucket_name, MaxKeys=1)
        # Some endpoints (MinIO) may return KeyCount; others may return Contents
        if resp.get("KeyCount", 0) > 0 or resp.get("Contents"):
            contents = resp.get("Contents", [])
            if contents:
                return True, contents[0].get("Key"), notes
        # No contents or listing not allowed
        return False, None, notes
    except ClientError as e:
        # Record the AWS error code for diagnostics
        code = e.response.get("Error", {}).get("Code")
        notes.append(f"list_objects error: {code}")
        return False, None, notes
    except Exception as e:
        notes.append(f"list_objects unexpected error: {e}")
        return False, None, notes


def load_buckets(path: str) -> List[str]:
    """
    Load bucket names from a plain text file.
    - Ignores blank lines and lines starting with '#'.
    - Returns a list of stripped bucket names.
    """
    if not path:
        raise ValueError("path must be provided to load_buckets()")
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Bucket list file not found: {path}")
    buckets: List[str] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            buckets.append(line)
    return buckets


# --- Skeletons for other cloud providers (implement when ready) ---

def gcp_check_bucket(bucket_name: str):
    """
    Placeholder for GCP bucket checks.
    Implement using google-cloud-storage (requires credentials/service account).
    Example flow:
      - Use storage.Client() (with GOOGLE_APPLICATION_CREDENTIALS)
      - client.get_bucket(bucket_name) to check existence
      - list blobs (with max results) to check public listing
    """
    raise NotImplementedError("GCP enumeration not implemented in this starter module.")


def azure_check_container(container_name: str):
    """
    Placeholder for Azure Blob Storage checks.
    Implement using azure-storage-blob (requires credentials).
    Example flow:
      - Use BlobServiceClient (with connection string or managed identity)
      - get_container_client(container_name) and try list_blobs(max_results=1)
    """
    raise NotImplementedError("Azure enumeration not implemented in this starter module.")


# Exported names
__all__ = [
    "ANON_S3",
    "aws_head_bucket_anonymous",
    "aws_list_sample_anonymous",
    "load_buckets",
    "gcp_check_bucket",
    "azure_check_container",
]
