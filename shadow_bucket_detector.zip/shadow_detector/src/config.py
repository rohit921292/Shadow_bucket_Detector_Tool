# src/config.py
"""
Configuration constants for the Shadow Data Leakage Detector.
Edit these values as needed for your environment/testing.
"""
BASE_SLEEP = 0.6        # base sleep (seconds) between target scans
JITTER = 0.35           # random jitter added to sleep
MAX_DOWNLOAD_BYTES = 200_000  # max bytes to download from an object (200 KB)
MAX_WORKERS = 3         # default concurrency (if using ThreadPoolExecutor)
USER_AGENT = "ShadowDetector/1.0 (mailto:rohithulawale1234@gmail.com)"
REPORT_FILENAME = "shadow_report.pdf"

